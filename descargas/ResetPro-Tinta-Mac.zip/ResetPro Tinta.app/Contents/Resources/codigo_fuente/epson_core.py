#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
"""
epson_core.py — "Motor" que habla con impresoras Epson por USB usando ReInkPy.

Funciona con cualquier modelo que ReInkPy conozca y para el que tenga la
llave de escritura. No tiene ventana: recibe una orden y responde con una
línea JSON. La app (epson_app.py) lo ejecuta sin contraseña de administrador.

Órdenes:
    detectar
    respaldo  <carpeta> <uid> <gid>
    reset     <carpeta> <uid> <gid> <clave>
    restaurar <archivo_respaldo>
"""

import ast
import datetime
import json
import os
import sys

# libusb: dentro de la app empaquetada; si no, donde la pone Homebrew
# (/opt/homebrew en Macs con chip Apple, /usr/local en Intel).
_rutas = "/opt/homebrew/lib:/usr/local/lib:"
if getattr(sys, "frozen", False):
    _rutas = sys._MEIPASS + ":" + _rutas
for var in ("DYLD_LIBRARY_PATH", "DYLD_FALLBACK_LIBRARY_PATH"):
    os.environ[var] = _rutas + os.environ.get(var, "")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import licencia  # noqa: E402

# En macOS no hace falta despegar el controlador de impresión para hablar con la
# impresora, y despegarlo era lo único que exigía la contraseña de administrador.
if sys.platform == "darwin":
    import usb.core  # noqa: E402
    usb.core.Device.is_kernel_driver_active = lambda self, interfaz: False


def responder(datos):
    """Imprime la respuesta como JSON en una línea y termina.

    Siempre sale con código 0: si saliera con error, macOS (osascript)
    descartaría la salida. Los errores van en la clave "error".
    """
    print(json.dumps(datos, ensure_ascii=False))
    sys.exit(0)


# --------------------------------------------------------------------------
# Conexión y lectura
# --------------------------------------------------------------------------

def conectar():
    import reinkpy
    try:
        dispositivo = reinkpy.Device.from_usb(manufacturer="EPSON")
    except Exception:
        dispositivo = None
    if dispositivo is None:
        responder({"error": "No encontré ninguna impresora Epson por USB. "
                            "Revisa que esté encendida y conectada."})
    return dispositivo, dispositivo.epson


def contadores_de(e):
    """Direcciones de tinta de desecho del modelo y el valor que les pone el reset."""
    grupo = e.spec.get_mem("waste counter")
    if not grupo:
        return {}
    return dict(zip(grupo["addr"], grupo["reset"]))


def es_compatible(e):
    """Se puede resetear si ReInkPy conoce el modelo, sus contadores y la llave."""
    return bool(e.spec.model and e.spec.wkey and contadores_de(e))


def leer_serie(dispositivo, e):
    try:
        return str(dispositivo.serial_number or "").strip().upper()
    except Exception:
        return ""


def estado(dispositivo, e):
    mapa = contadores_de(e)
    lectura = dict(e.read_eeprom(*mapa)) if mapa else {}
    filas = []
    for entrada in e.spec.mem:
        if "waste counter" not in entrada["desc"].lower():
            continue
        addrs = entrada["addr"]
        valores = [lectura.get(a) for a in addrs]
        filas.append({
            "nombre": entrada["desc"],
            "direcciones": addrs,
            "valores": valores,
            "reset": [mapa[a] for a in addrs],
            "pendiente": any(v != mapa[a] for a, v in zip(addrs, valores)),
        })
    detectado = getattr(e, "detected_model", None)
    return {
        "modelo": e.spec.model or detectado or "Desconocido",
        "serie": leer_serie(dispositivo, e),
        "compatible": es_compatible(e),
        "contadores": filas,
        "necesita_reset": any(f["pendiente"] for f in filas),
    }


def leer_respaldo(ruta):
    """Lee un respaldo de esta app o de la primera versión (lista o 'EEPROM: [...]').

    Regresa {"modelo", "serie", "memoria"} o None si el archivo no es un respaldo.
    """
    try:
        with open(ruta) as f:
            texto = f.read().strip()
        if texto.startswith("EEPROM:"):
            texto = texto.splitlines()[0][len("EEPROM:"):]
        datos = ast.literal_eval(texto)
    except (OSError, ValueError, SyntaxError, IndexError):
        return None
    if isinstance(datos, list):
        datos = {"modelo": None, "serie": None, "memoria": datos}
    if not isinstance(datos, dict) or not isinstance(datos.get("memoria"), list):
        return None
    try:
        dict(datos["memoria"])
    except (TypeError, ValueError):
        return None
    return datos


def guardar_respaldo(e, serie, carpeta, uid, gid):
    datos = e.read_eeprom()
    fecha = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    nombre = f"respaldo_{(e.spec.model or 'Epson').replace(' ', '_')}_{serie}_{fecha}.txt"
    ruta = os.path.join(carpeta, nombre)
    with open(ruta, "w") as f:
        f.write(repr({"modelo": e.spec.model, "serie": serie, "memoria": datos}))
    os.chown(ruta, int(uid), int(gid))  # que el archivo sea del usuario, no de root
    return ruta


# --------------------------------------------------------------------------
# Órdenes
# --------------------------------------------------------------------------

def main():
    if len(sys.argv) < 2:
        responder({"error": "Falta la orden"})
    orden, args = sys.argv[1], sys.argv[2:]

    try:
        dispositivo, e = conectar()
        info = estado(dispositivo, e)

        if orden == "detectar":
            responder(info)

        if not info["compatible"]:
            responder({"error": f"El modelo {info['modelo']} no es compatible todavía."})

        if orden == "respaldo":
            ruta = guardar_respaldo(e, info["serie"], *args[:3])
            responder({"respaldo": ruta, **info})

        elif orden == "reset":
            carpeta, uid, gid, clave = args[:4]
            if not licencia.es_valida(info["serie"], clave):
                responder({"error": "La clave no es válida para esta impresora."})
            ruta = guardar_respaldo(e, info["serie"], carpeta, uid, gid)
            if not e.reset_waste():
                responder({"error": "La impresora no aceptó el reset. "
                                    f"Tu respaldo está en {ruta}"})
            responder({"respaldo": ruta, **estado(dispositivo, e)})

        elif orden == "restaurar":
            guardado = leer_respaldo(args[0])
            if not guardado:
                responder({"error": "Ese archivo no es un respaldo de ResetPro Tinta."})
            if guardado["serie"] is None:
                # Respaldo de la primera versión: no dice de qué impresora es.
                if not licencia.clave_guardada(info["serie"]):
                    responder({"error": "Ese respaldo es de una versión anterior y no dice de qué "
                                        "impresora es. Para usarlo, activa la licencia de esta impresora."})
            elif guardado.get("modelo") != e.spec.model or guardado.get("serie") != info["serie"]:
                responder({"error": "Ese respaldo es de otra impresora."})
            memoria = dict(guardado["memoria"])
            pares = [(a, memoria[a]) for a in contadores_de(e) if memoria.get(a) is not None]
            if not e.write_eeprom(*pares, atomic=True):
                responder({"error": "La impresora no aceptó la restauración."})
            responder(estado(dispositivo, e))

        else:
            responder({"error": f"Orden desconocida: {orden}"})

    except SystemExit:
        raise
    except Exception as error:
        responder({"error": f"{type(error).__name__}: {error}"})


if __name__ == "__main__":
    main()
