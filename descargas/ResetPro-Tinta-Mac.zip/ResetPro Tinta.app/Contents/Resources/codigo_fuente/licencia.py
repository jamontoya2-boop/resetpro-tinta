# SPDX-License-Identifier: AGPL-3.0-or-later
"""
licencia.py — Comprueba las claves de activación de ResetPro Tinta.

Cada clave es una FIRMA DIGITAL (Ed25519) del número de serie de una
impresora. La app solo trae la llave PÚBLICA, que sirve para comprobar
firmas pero no para crearlas. La llave PRIVADA, la única que puede crear
claves, la guarda el vendedor y nunca se incluye en la app.

Así, aunque el código sea público (AGPL), nadie puede inventar una clave
válida sin la llave privada.
"""

import base64
import json
import os
import sys


def carpeta_datos():
    """Dónde está vendedor.json: junto al código o, en la app empaquetada, en Contents/Resources."""
    if getattr(sys, "frozen", False):
        return os.path.normpath(os.path.join(os.path.dirname(sys.executable), "..", "Resources"))
    return os.path.dirname(os.path.abspath(__file__))


def datos_vendedor():
    """Precio, contacto, forma de pago y llave pública que pone la app del vendedor."""
    try:
        with open(os.path.join(carpeta_datos(), "vendedor.json"), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


# Las pone la app del vendedor en vendedor.json. Vacías = licencias aún no configuradas.
# llave_publica comprueba las claves que el vendedor genera a mano; llave_servidor, las
# que genera el servidor de pagos después de cobrar con Mercado Pago.
_DATOS = datos_vendedor()
LLAVE_PUBLICA = _DATOS.get("llave_publica", "")
LLAVE_SERVIDOR = _DATOS.get("llave_servidor", "")
SERVIDOR = _DATOS.get("servidor", "").rstrip("/")

PREFIJO = b"EPSONRESET1|"
ARCHIVO = os.path.expanduser("~/Library/Application Support/EpsonReset/licencias.json")


def configurada():
    return bool(LLAVE_PUBLICA or LLAVE_SERVIDOR)


def _mensaje(serie):
    return PREFIJO + serie.strip().upper().encode("ascii")


def limpiar_clave(clave):
    """Quita guiones, espacios y saltos de línea que se cuelan al copiar."""
    return "".join(c for c in clave.upper() if c.isalnum())


def formatear_clave(firma: bytes) -> str:
    """64 bytes -> texto base32 en grupos de 8, fácil de copiar."""
    t = base64.b32encode(firma).decode().rstrip("=")
    return "-".join(t[i:i + 8] for i in range(0, len(t), 8))


def es_valida(serie, clave):
    """True si la clave corresponde a ese número de serie."""
    if not configurada() or not serie:
        return False
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    try:
        t = limpiar_clave(clave)
        firma = base64.b32decode(t + "=" * (-len(t) % 8))
    except (ValueError, TypeError):
        return False
    for llave in (LLAVE_PUBLICA, LLAVE_SERVIDOR):
        if not llave:
            continue
        try:
            Ed25519PublicKey.from_public_bytes(base64.b64decode(llave)).verify(firma, _mensaje(serie))
            return True
        except (InvalidSignature, ValueError, TypeError):
            pass
    return False


# --- Pago en línea (Mercado Pago, a través del servidor) -----------------------

def url_pago(serie, modelo):
    """Página que cobra la licencia de esta impresora ("" si no hay servidor)."""
    if not SERVIDOR:
        return ""
    import urllib.parse
    return f"{SERVIDOR}/pagar?" + urllib.parse.urlencode({"serie": serie.strip().upper(), "modelo": modelo})


def clave_del_servidor(serie):
    """Pregunta al servidor si ya se pagó esta impresora. Regresa la clave o None."""
    if not SERVIDOR or not serie:
        return None
    import ssl
    import urllib.parse
    import urllib.request
    try:
        import certifi
        contexto = ssl.create_default_context(cafile=certifi.where())
    except ImportError:
        contexto = ssl.create_default_context()
    url = f"{SERVIDOR}/clave?" + urllib.parse.urlencode({"serie": serie.strip().upper()})
    try:
        with urllib.request.urlopen(url, timeout=10, context=contexto) as r:
            datos = json.load(r)
    except (OSError, ValueError):
        return None
    clave = datos.get("clave") if datos.get("estado") == "pagada" else None
    return clave if clave and es_valida(serie, clave) else None


# --- Claves guardadas en esta Mac -----------------------------------------

def _cargar():
    try:
        with open(ARCHIVO) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def clave_guardada(serie):
    clave = _cargar().get(serie.strip().upper())
    return clave if clave and es_valida(serie, clave) else None


def guardar_clave(serie, clave):
    datos = _cargar()
    datos[serie.strip().upper()] = clave.strip()
    os.makedirs(os.path.dirname(ARCHIVO), exist_ok=True)
    with open(ARCHIVO, "w") as f:
        json.dump(datos, f, indent=2)
