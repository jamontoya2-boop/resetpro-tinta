#!/usr/bin/env python3
# SPDX-License-Identifier: AGPL-3.0-or-later
"""
epson_app.py — Ventana de ResetPro Tinta.

Detectar la impresora y ver sus contadores es gratis. Para resetear se
necesita una clave de activación ligada al número de serie de la impresora.

La ventana no toca la impresora: le pide el trabajo a epson_core.py en un
proceso aparte. En la app empaquetada, el mismo ejecutable hace de motor
cuando se abre con --motor.
"""

import json
import os
import platform
import shlex
import subprocess
import sys
import threading
import urllib.parse
import webbrowser
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import licencia  # noqa: E402

MOTOR = os.path.join(AQUI, "epson_core.py")
PYTHON = sys.executable
EMPAQUETADA = getattr(sys, "frozen", False)
ROJO = "#d92d20"
CARPETA_RESPALDOS = os.path.expanduser("~/Documents/Respaldos ResetPro Tinta")
VERSION = "1.2"
SOPORTE = "soporte@resetprotinta.com"


datos_vendedor = licencia.datos_vendedor


def comando_motor(*args):
    """Lo que hay que ejecutar para correr el motor con estas órdenes."""
    if EMPAQUETADA:
        return [PYTHON, "--motor", *args]
    return [PYTHON, MOTOR, *args]


# --------------------------------------------------------------------------
# Comunicación con el motor
# --------------------------------------------------------------------------

def ejecutar_motor(*args):
    """Corre epson_core.py y regresa su respuesta (dict).

    Primero lo intenta sin permisos especiales; solo si macOS niega el acceso
    al USB pide la contraseña de administrador.
    """
    r = subprocess.run(comando_motor(*args), capture_output=True, text=True)
    try:
        respuesta = json.loads(r.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError):
        respuesta = {"error": "Respuesta inesperada del motor."}
    if "permission" not in str(respuesta.get("error", "")).lower():
        return respuesta
    return ejecutar_motor_admin(*args)


def ejecutar_motor_admin(*args):
    """Corre epson_core.py como administrador (pide la contraseña)."""
    comando = " ".join(shlex.quote(p) for p in comando_motor(*args)) + " 2>/dev/null"
    comando_as = comando.replace("\\", "\\\\").replace('"', '\\"')
    script = f'do shell script "{comando_as}" with administrator privileges'
    r = subprocess.run(["osascript", "-e", script], capture_output=True, text=True)
    if not r.stdout.strip():
        if "-128" in r.stderr:
            return {"error": "Cancelaste la contraseña."}
        return {"error": r.stderr.strip() or "El motor no respondió."}
    try:
        return json.loads(r.stdout.strip().splitlines()[-1])
    except ValueError:
        return {"error": "Respuesta inesperada del motor."}


# --------------------------------------------------------------------------
# Ventana
# --------------------------------------------------------------------------

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ResetPro Tinta")
        self.geometry("560x580")
        self.minsize(520, 540)
        self.info = None  # última respuesta de "detectar"

        m = ttk.Frame(self, padding=20)
        m.pack(fill="both", expand=True)

        cab = ttk.Frame(m)
        cab.pack(fill="x")
        ttk.Label(cab, text="ResetPro Tinta", font=("Helvetica", 22, "bold")).pack(side="left")
        ttk.Button(cab, text="Acerca de", command=self.acerca).pack(side="right")
        ttk.Button(cab, text="Reporte para soporte", command=self.enviar_reporte).pack(side="right", padx=6)

        self.lbl_modelo = ttk.Label(m, text="Ninguna impresora detectada",
                                    font=("Helvetica", 15, "bold"))
        self.lbl_modelo.pack(anchor="w", pady=(14, 0))
        self.lbl_serie = ttk.Label(m, text="Conéctala por USB y presiona Buscar.", foreground="gray")
        self.lbl_serie.pack(anchor="w")
        self.lbl_compat = ttk.Label(m, text="", font=("Helvetica", 13, "bold"))
        self.lbl_compat.pack(anchor="w", pady=(6, 10))

        # Tabla de contadores
        cols = ("nombre", "dirs", "actual", "reset")
        self.tabla = ttk.Treeview(m, columns=cols, show="headings", height=5)
        for c, t, w in zip(cols, ("Contador", "Direcciones", "Actual", "Tras reset"),
                           (170, 130, 100, 100)):
            self.tabla.heading(c, text=t)
            self.tabla.column(c, width=w, anchor="w")
        self.tabla.pack(fill="x")

        # Licencia
        lic = ttk.LabelFrame(m, text="Licencia", padding=10)
        lic.pack(fill="x", pady=12)
        self.lbl_lic = ttk.Label(lic, text="—", wraplength=330)
        self.lbl_lic.pack(side="left", fill="x", expand=True)
        self.btn_activar = ttk.Button(lic, text="Activar…", command=self.activar)
        self.btn_activar.pack(side="right")
        self.btn_comprar = ttk.Button(lic, text="Comprar", width=9, command=self.comprar)
        self.btn_comprar.pack(side="right", padx=4)

        # Acciones
        bot = ttk.Frame(m)
        bot.pack(fill="x")
        self.btn_buscar = ttk.Button(bot, text="Buscar", command=self.buscar)
        self.btn_respaldo = ttk.Button(bot, text="Respaldo", command=self.respaldo)
        self.btn_reset = ttk.Button(bot, text="Resetear", command=self.resetear)
        self.btn_restaurar = ttk.Button(bot, text="Restaurar…", command=self.restaurar)
        self.acciones = [self.btn_buscar, self.btn_respaldo, self.btn_reset, self.btn_restaurar]
        for i, b in enumerate(self.acciones):
            b.grid(row=0, column=i, sticky="ew", padx=2)
            bot.columnconfigure(i, weight=1)

        self.barra = ttk.Progressbar(m, mode="indeterminate")
        self.barra.pack(fill="x", pady=(12, 0))
        self.lbl_estado = ttk.Label(m, text="", wraplength=500)
        self.lbl_estado.pack(anchor="w", pady=(8, 0))

        self.actualizar_botones()
        # Al abrir, revisar la impresora de una vez: si ya se pagó (p. ej. en OXXO), se activa sola.
        self.after(600, self.buscar)

    # -- Estado de la ventana ------------------------------------------------

    def licencia_activa(self):
        return bool(self.info and licencia.clave_guardada(self.info["serie"]))

    def actualizar_botones(self, ocupado=False):
        compatible = bool(self.info and self.info.get("compatible"))
        for b in self.acciones:
            b.state(["disabled"] if ocupado else ["!disabled"])
        if not ocupado:
            for b in (self.btn_respaldo, self.btn_reset, self.btn_restaurar):
                b.state(["!disabled"] if compatible else ["disabled"])

        if not self.info:
            texto, comprar = "Busca una impresora para ver si se puede resetear.", False
        elif not compatible:
            texto, comprar = "Este modelo no es compatible; no necesitas licencia.", False
        elif not licencia.configurada():
            texto, comprar = "Las licencias aún no están configuradas en esta copia.", False
        elif self.licencia_activa():
            texto, comprar = f"✅ Activa para la impresora {self.info['serie']}.", False
        else:
            texto, comprar = ("Detectar y respaldar es gratis. Para resetear esta "
                              "impresora necesitas una licencia."), True
        self.lbl_lic.config(text=texto)
        for b in (self.btn_comprar, self.btn_activar):
            b.state(["!disabled"] if comprar and not ocupado else ["disabled"])

    def mostrar(self, r):
        self.info = r
        self.lbl_modelo.config(text=f"EPSON {r['modelo']}")
        self.lbl_serie.config(text=f"Número de serie: {r['serie'] or 'desconocido'}")
        if not r["compatible"]:
            self.lbl_compat.config(text="✖ No compatible: no hay datos de reset para este modelo",
                                   foreground="#b42318")
        elif r["necesita_reset"]:
            self.lbl_compat.config(text="⚠️ Almohadillas llenas · esta impresora necesita reset",
                                   foreground=ROJO)
        else:
            self.lbl_compat.config(text="✔ Compatible · se puede resetear",
                                   foreground="#067647")
        self.tabla.delete(*self.tabla.get_children())
        for c in r["contadores"]:
            fmt = lambda xs: ", ".join("?" if v is None else str(v) for v in xs)
            self.tabla.insert("", "end", values=(
                c["nombre"], ", ".join(str(a) for a in c["direcciones"]),
                fmt(c["valores"]), fmt(c["reset"])))

    # -- Trabajo en segundo plano ------------------------------------------

    def trabajar(self, mensaje, args, al_terminar=None):
        self.actualizar_botones(ocupado=True)
        self.barra.start(10)
        self.lbl_estado.config(text=mensaje, foreground="", font="TkDefaultFont")

        def hilo():
            r = ejecutar_motor(*args)
            self.after(0, lambda: self.terminar(r, al_terminar))

        threading.Thread(target=hilo, daemon=True).start()

    def terminar(self, r, al_terminar):
        self.barra.stop()
        if "error" in r:
            self.lbl_estado.config(text="❌ " + r["error"])
        else:
            if "modelo" in r:
                self.mostrar(r)
            if al_terminar:
                al_terminar(r)
        self.actualizar_botones()

    def _ids(self):
        os.makedirs(CARPETA_RESPALDOS, exist_ok=True)
        return [CARPETA_RESPALDOS, str(os.getuid()), str(os.getgid())]

    # -- Acciones -------------------------------------------------------------

    def buscar(self):
        def listo(r):
            if not r["compatible"]:
                msg = f"Encontré la {r['modelo']}, pero todavía no es compatible."
            elif r["necesita_reset"] and self.licencia_activa():
                msg = "⚠️ ATENCIÓN: la impresora tiene las almohadillas llenas. Presiona Resetear para desbloquearla."
            elif r["necesita_reset"]:
                msg = ("⚠️ ATENCIÓN: la impresora tiene las almohadillas llenas y puede bloquearse. "
                       "Compra tu licencia para resetearla.")
            elif self.licencia_activa():
                msg = "Se puede resetear. Presiona Resetear cuando estés listo."
            else:
                msg = "¡Buenas noticias! Esta impresora sí se puede resetear. Compra tu licencia para continuar."
            self.lbl_estado.config(text=msg)
            if r["compatible"] and r["necesita_reset"]:
                self.lbl_estado.config(foreground=ROJO, font=("Helvetica", 13, "bold"))
            if r["compatible"] and licencia.configurada() \
                    and not licencia.clave_guardada(r["serie"]):
                self.after(200, self.revisar_pago_o_comprar)

        self.trabajar("Buscando impresora…", ["detectar"], listo)

    def respaldo(self):
        self.trabajar("Leyendo toda la memoria (tarda un poco)…", ["respaldo", *self._ids()],
                      lambda r: self.lbl_estado.config(text=f"✅ Respaldo: {r['respaldo']}"))

    def resetear(self):
        if not licencia.configurada():
            messagebox.showwarning("Licencias", "Esta copia de la app no tiene licencias configuradas.")
            return
        clave = licencia.clave_guardada(self.info["serie"])
        if not clave:
            self.comprar()
            return
        if not messagebox.askyesno(
                "Resetear contador",
                "El reset NO limpia las almohadillas.\n\n"
                "¿Están limpias o tienes un frasco externo de desecho?\n\n"
                "Se hará un respaldo automático antes de escribir."):
            return

        def listo(r):
            self.lbl_estado.config(text=f"✅ Reset hecho. Respaldo: {r['respaldo']}")
            messagebox.showinfo("Listo", "Apaga la impresora, espera 10 segundos y préndela.")

        self.trabajar("Respaldando y reseteando…", ["reset", *self._ids(), clave], listo)

    def restaurar(self):
        ruta = filedialog.askopenfilename(title="Elige un respaldo", initialdir=CARPETA_RESPALDOS,
                                          filetypes=[("Respaldos", "respaldo*.txt"), ("Texto", "*.txt")])
        if ruta and messagebox.askyesno("Restaurar", f"¿Escribir los contadores de:\n{os.path.basename(ruta)}?"):
            self.trabajar("Restaurando contadores…", ["restaurar", ruta],
                          lambda r: self.lbl_estado.config(text="✅ Contadores restaurados."))

    # -- Licencia ---------------------------------------------------------------

    # -- Pago en línea ------------------------------------------------------

    def revisar_pago_o_comprar(self):
        """Si esta impresora ya se pagó en línea (p. ej. en OXXO), activa sola; si no, abre Comprar."""
        if not licencia.SERVIDOR:
            self.comprar()
            return
        serie = self.info["serie"]

        def hilo():
            clave = licencia.clave_del_servidor(serie)
            self.after(0, lambda: self.pago_confirmado(clave) if clave else self.comprar())

        threading.Thread(target=hilo, daemon=True).start()

    def pago_confirmado(self, clave, ventana=None, serie=None):
        """serie: la impresora que se pagó (puede no ser la que está conectada ahora)."""
        self.esperando_pago = False
        serie = serie or self.info["serie"]
        if licencia.clave_guardada(serie):
            return  # ya se activó (p. ej. por Buscar mientras se esperaba)
        licencia.guardar_clave(serie, clave)
        if ventana is not None and ventana.winfo_exists():
            ventana.destroy()
        self.actualizar_botones()
        self.lbl_estado.config(text="✅ Pago confirmado. Presiona Resetear para desbloquear tu impresora.",
                               foreground="", font="TkDefaultFont")
        messagebox.showinfo("Licencia activada", "¡Gracias! Tu pago se confirmó y ya puedes resetear esta impresora.\n\n"
                            f"¿Algún problema? Escríbenos a {SOPORTE}")

    def esperar_pago(self, ventana, etiqueta, serie, intentos=0):
        """Pregunta al servidor cada 5 segundos durante 20 minutos, aunque cierren la ventana de
        compra: si el cliente paga y la cierra, la licencia se activa sola mientras la app esté abierta."""
        abierta = ventana.winfo_exists()
        if intentos >= 240:  # 20 minutos
            self.esperando_pago = False
            aviso = ("Si pagaste en OXXO o por transferencia, puede tardar unas horas. "
                     "Cuando se confirme, abre la app y presiona Buscar.")
            (etiqueta if abierta else self.lbl_estado).config(text=aviso)
            return
        if not abierta and intentos and not getattr(self, "aviso_espera", False):
            self.aviso_espera = True
            self.lbl_estado.config(text="⏳ Esperando la confirmación de tu pago. "
                                        "Deja la app abierta: la licencia se activa sola.")

        def hilo():
            clave = licencia.clave_del_servidor(serie)
            self.after(0, lambda: self.pago_confirmado(clave, ventana, serie) if clave
                       else self.after(5000, lambda: self.esperar_pago(ventana, etiqueta, serie, intentos + 1)))

        threading.Thread(target=hilo, daemon=True).start()

    def comprar(self):
        if not self.info:
            return
        if licencia.SERVIDOR:
            self.comprar_en_linea()
        else:
            self.comprar_manual()

    def comprar_en_linea(self):
        v = datos_vendedor()
        ven = tk.Toplevel(self)
        ven.title("Comprar licencia")
        ven.resizable(False, False)
        f = ttk.Frame(ven, padding=20)
        f.pack()
        ttk.Label(f, text="Esta impresora sí se puede resetear",
                  font=("Helvetica", 15, "bold")).pack(anchor="w")
        ttk.Label(f, text=f"Licencia para 1 impresora: {v.get('precio', 'consulta el precio')}",
                  font=("Helvetica", 13)).pack(anchor="w", pady=(4, 2))
        ttk.Label(f, text="✅ Licencia perpetua: resetea esta impresora todas las veces que lo necesites, "
                          "sin volver a pagar.", font=("Helvetica", 12, "bold"),
                  wraplength=440).pack(anchor="w", pady=(0, 12))
        ttk.Label(f, text="Paga con tarjeta, OXXO o tu cuenta de Mercado Pago. "
                          "En cuanto se confirme el pago, la licencia se activa sola aquí.",
                  wraplength=440).pack(anchor="w")
        espera = ttk.Label(f, text="", foreground="gray", wraplength=440)

        def pagar():
            webbrowser.open(licencia.url_pago(self.info["serie"], self.info["modelo"]))
            btn_pagar.config(text="Abrir el pago otra vez")
            espera.config(text="⏳ Esperando tu pago… deja esta ventana abierta.")
            if not getattr(self, "esperando_pago", False):
                self.esperando_pago, self.aviso_espera = True, False
                self.esperar_pago(ven, espera, self.info["serie"])

        btn_pagar = ttk.Button(f, text="Pagar con Mercado Pago", command=pagar)
        btn_pagar.pack(anchor="w", pady=(12, 4))
        espera.pack(anchor="w")
        b = ttk.Frame(f)
        b.pack(fill="x", pady=(14, 0))
        ttk.Button(b, text="Cerrar", command=ven.destroy).pack(side="right")

    def comprar_manual(self):
        v = datos_vendedor()
        datos = f"Modelo: EPSON {self.info['modelo']}\nSerie: {self.info['serie']}"
        mensaje = ("Hola, quiero comprar la licencia de ResetPro Tinta.\n"
                   f"{datos}\n"
                   "Te envío mi comprobante de pago.")

        ven = tk.Toplevel(self)
        ven.title("Comprar licencia")
        ven.resizable(False, False)
        f = ttk.Frame(ven, padding=20)
        f.pack()
        ttk.Label(f, text="Esta impresora sí se puede resetear",
                  font=("Helvetica", 15, "bold")).pack(anchor="w")
        ttk.Label(f, text=f"Licencia para 1 impresora: {v.get('precio', 'consulta el precio')}",
                  font=("Helvetica", 13)).pack(anchor="w", pady=(4, 12))

        def paso(texto):
            ttk.Label(f, text=texto, font=("Helvetica", 13, "bold")).pack(anchor="w", pady=(10, 2))

        paso("1. Realiza tu pago")
        ttk.Label(f, text=v.get("pago") or "Escríbenos por WhatsApp y te decimos cómo pagar.",
                  wraplength=440).pack(anchor="w")

        paso("2. Envía tu comprobante de pago con estos datos")
        caja = tk.Text(f, height=2, width=44, font=("Menlo", 12))
        caja.insert("1.0", datos)
        caja.config(state="disabled")
        caja.pack(anchor="w", pady=(2, 6))
        envio = ttk.Frame(f)
        envio.pack(anchor="w")
        numero = "".join(c for c in v.get("whatsapp", "") if c.isdigit())
        if numero:
            ttk.Button(envio, text="Enviar por WhatsApp", command=lambda: webbrowser.open(
                f"https://wa.me/{numero}?text={urllib.parse.quote(mensaje)}")).pack(side="left")
        if v.get("correo"):
            ttk.Button(envio, text="Enviar por correo", command=lambda: webbrowser.open(
                f"mailto:{v['correo']}?subject={urllib.parse.quote('Licencia ResetPro Tinta')}"
                f"&body={urllib.parse.quote(mensaje)}")).pack(side="left", padx=6)

        def copiar():
            self.clipboard_clear()
            self.clipboard_append(mensaje)
            btn_copiar.config(text="¡Copiado!")

        btn_copiar = ttk.Button(envio, text="Copiar datos", command=copiar)
        btn_copiar.pack(side="left")
        ttk.Label(f, text="No olvides adjuntar la foto o captura de tu comprobante.",
                  foreground="gray").pack(anchor="w", pady=(4, 0))

        paso("3. Recibe tu clave y actívala")
        ttk.Label(f, text="Te enviaremos una clave. Pégala con el botón «Ya tengo mi clave…».",
                  wraplength=440).pack(anchor="w")
        ttk.Label(f, text="La licencia queda guardada para esta impresora: úsala ahora o cuando la necesites.",
                  foreground="gray", wraplength=440).pack(anchor="w", pady=(4, 0))
        b = ttk.Frame(f)
        b.pack(fill="x", pady=(14, 0))
        ttk.Button(b, text="Ya tengo mi clave…", command=lambda: (ven.destroy(), self.activar())).pack(side="right")
        ttk.Button(b, text="Cerrar", command=ven.destroy).pack(side="right", padx=6)

    def activar(self):
        if not self.info:
            return
        clave = self.pedir_clave()
        if not clave:
            return
        if licencia.es_valida(self.info["serie"], clave):
            licencia.guardar_clave(self.info["serie"], clave)
            self.actualizar_botones()
            messagebox.showinfo("Licencia activada", "¡Gracias! Ya puedes resetear esta impresora.\n\n"
                                f"¿Algún problema? Escríbenos a {SOPORTE}")
        else:
            messagebox.showerror("Clave no válida",
                                 "Esa clave no corresponde a esta impresora. "
                                 "Revisa que la copiaste completa.\n\n"
                                 f"Si el problema sigue, escríbenos a {SOPORTE} con el número de serie de tu impresora.")

    def pedir_clave(self):
        """Ventana propia para pegar la clave (simpledialog de Tk 9 se esconde en macOS)."""
        ven = tk.Toplevel(self)
        ven.title("Activar licencia")
        ven.resizable(False, False)
        ven.transient(self)
        resultado = {"clave": None}
        f = ttk.Frame(ven, padding=20)
        f.pack()
        ttk.Label(f, text=f"Pega la clave para la impresora {self.info['serie']}:").pack(anchor="w")
        campo = ttk.Entry(f, width=44, font=("Menlo", 12))
        campo.pack(anchor="w", pady=10)

        def pegar():
            try:
                campo.delete(0, "end")
                campo.insert(0, self.clipboard_get().strip())
            except tk.TclError:
                pass

        def aceptar(_evento=None):
            resultado["clave"] = campo.get().strip()
            ven.destroy()

        b = ttk.Frame(f)
        b.pack(fill="x")
        ttk.Button(b, text="Pegar", command=pegar).pack(side="left")
        ttk.Button(b, text="Activar", command=aceptar).pack(side="right")
        ttk.Button(b, text="Cancelar", command=ven.destroy).pack(side="right", padx=6)
        ven.bind("<Return>", aceptar)
        ven.bind("<Escape>", lambda _e: ven.destroy())
        ven.update_idletasks()
        ven.lift()
        ven.attributes("-topmost", True)
        ven.after(300, lambda: ven.attributes("-topmost", False))
        ven.focus_force()
        campo.focus_set()
        ven.grab_set()
        self.wait_window(ven)
        return resultado["clave"]

    def reporte(self):
        """Todo lo que soporte necesita saber, en texto para pegar en un correo."""
        r = self.info or {}
        d = r.get("diagnostico") or {}
        mac = platform.mac_ver()[0] or "?"
        lineas = [
            f"ResetPro Tinta {VERSION} · macOS {mac} · {platform.machine()}",
            f"Impresora: EPSON {r.get('modelo', 'no detectada')} · serie {r.get('serie') or '?'}",
            f"Compatible: {'sí' if r.get('compatible') else 'no'} · "
            f"licencia activa: {'sí' if self.licencia_activa() else 'no'}",
            f"Estado: {d.get('estado', '?')} · {d.get('texto', 'sin leer')}"
            + (f" (código {d['codigo']})" if d.get("codigo") else ""),
        ]
        for c in r.get("contadores", []):
            lineas.append(f"  {c['nombre']} {c['direcciones']}: {c['valores']} (tras reset {c['reset']})")
        if not r:
            lineas.append("(Conecta la impresora y presiona Buscar antes de enviar el reporte.)")
        return "\n".join(lineas)

    def enviar_reporte(self):
        texto = self.reporte()
        self.clipboard_clear()
        self.clipboard_append(texto)
        cuerpo = "Hola, necesito ayuda con ResetPro Tinta.\n\n(Cuéntanos qué pasó aquí)\n\n--- Reporte ---\n" + texto
        webbrowser.open(f"mailto:{SOPORTE}?" + urllib.parse.urlencode(
            {"subject": "Ayuda con ResetPro Tinta", "body": cuerpo}, quote_via=urllib.parse.quote))
        messagebox.showinfo("Reporte para soporte",
                            "Se abrió un correo para soporte con el reporte de tu impresora.\n\n"
                            f"Si no se abrió, el reporte ya está copiado: pégalo en un correo a {SOPORTE}.")

    def acerca(self):
        messagebox.showinfo(
            "Acerca de ResetPro Tinta",
            f"ResetPro Tinta {VERSION}  ·  para impresoras Epson\n\n"
            f"Soporte: {SOPORTE}\n\n"
            "Usa ReInkPy · Licencia AGPL v3 (archivo LICENSE).\n"
            "Sin garantía. El reset no reemplaza las almohadillas de tinta.")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--motor":
        import epson_core
        sys.argv = [sys.argv[0], *sys.argv[2:]]
        epson_core.main()
    else:
        App().mainloop()
